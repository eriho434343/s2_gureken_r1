#!/usr/bin/env python3
"""Build a private, browser-importable S2 source library.

The output ZIP contains source PDFs/images, page previews, and a question-to-source
manifest. It is intentionally written with ZIP_STORED so the web app can import it
without a third-party ZIP library. Keep the output local; never commit it to GitHub.
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
from collections import defaultdict
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Sequence

HASH_UNICODE_RE = re.compile(r"#U([0-9a-fA-F]{4})")
BLANK_RE = re.compile(r"【([^】]*)】")
CIRCLED = "①②③④⑤⑥⑦⑧⑨⑩⑪⑫⑬⑭⑮⑯⑰⑱⑲⑳㉑㉒㉓㉔㉕㉖㉗㉘㉙㉚㉛㉜㉝㉞㉟㊱㊲㊳㊴㊵㊶㊷㊸㊹㊺㊻㊼㊽㊾㊿"
SUPPORTED_DOC_EXTS = {".pdf", ".png", ".jpg", ".jpeg", ".webp"}


@dataclass
class PageData:
    number: int
    text: str
    norm: str
    grams3: set[str] = field(default_factory=set)
    grams4: set[str] = field(default_factory=set)


@dataclass
class Document:
    id: str
    kind: str
    rel_path: Path
    source_path: Path
    package_path: str
    name: str
    mime: str
    page_count: int
    aliases: list[tuple[str, int]]
    pages: list[PageData] = field(default_factory=list)

    @property
    def is_pdf(self) -> bool:
        return self.source_path.suffix.lower() == ".pdf"

    @property
    def is_image(self) -> bool:
        return self.source_path.suffix.lower() in {".png", ".jpg", ".jpeg", ".webp"}


@dataclass
class Candidate:
    doc: Document
    match_score: int
    explicit: bool


@dataclass
class PageMatch:
    doc: Document
    page: int | None
    score: float
    excerpt: str
    boxes: list[dict[str, float]]
    preview_path: str | None
    page_label: str
    explicit: bool
    marker_mode: str | None


def log(message: str) -> None:
    print(message, flush=True)


def run(cmd: Sequence[str], *, text: bool = True) -> subprocess.CompletedProcess:
    try:
        return subprocess.run(
            list(cmd),
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=text,
            errors="replace" if text else None,
        )
    except subprocess.CalledProcessError as exc:
        stderr = exc.stderr if isinstance(exc.stderr, str) else ""
        raise RuntimeError(f"command failed: {' '.join(cmd)}\n{stderr[-1500:]}") from exc


def require_commands(names: Iterable[str]) -> None:
    missing = [name for name in names if shutil.which(name) is None]
    if missing:
        raise SystemExit("Required command(s) not found: " + ", ".join(missing))


def decode_hash_unicode(value: str) -> str:
    return HASH_UNICODE_RE.sub(lambda m: chr(int(m.group(1), 16)), value)


def normalize_text(value: str) -> str:
    value = unicodedata.normalize("NFKC", value or "").lower()
    # Keep letters/numbers/Japanese characters; discard punctuation and whitespace.
    return "".join(ch for ch in value if ch.isalnum() or "ぁ" <= ch <= "龥" or "々" == ch)


def normalize_alias(value: str) -> str:
    return normalize_text(Path(value).stem)


def ngrams(value: str, n: int) -> set[str]:
    if not value:
        return set()
    if len(value) <= n:
        return {value}
    return {value[i : i + n] for i in range(len(value) - n + 1)}


def safe_member_path(name: str, kind: str) -> Path | None:
    decoded = decode_hash_unicode(name).replace("\\", "/")
    parts = [p for p in decoded.split("/") if p not in ("", ".")]
    if not parts or decoded.endswith("/"):
        return None
    if any(p == ".." for p in parts):
        raise ValueError(f"unsafe ZIP member: {name}")
    if parts[0] in {"共通", "ソリューション"}:
        parts = parts[1:]
    if not parts:
        return None
    return Path(*parts)


def extract_source_zip(zip_path: Path, out_dir: Path, kind: str) -> None:
    with zipfile.ZipFile(zip_path) as zf:
        for info in zf.infolist():
            rel = safe_member_path(info.filename, kind)
            if rel is None:
                continue
            target = out_dir / kind / rel
            target.parent.mkdir(parents=True, exist_ok=True)
            with zf.open(info) as src, target.open("wb") as dst:
                shutil.copyfileobj(src, dst)


def pdf_page_count(path: Path) -> int:
    out = run(["pdfinfo", str(path)]).stdout
    match = re.search(r"^Pages:\s+(\d+)", out, re.MULTILINE)
    if not match:
        raise RuntimeError(f"could not read page count: {path}")
    return int(match.group(1))


def split_pdf_text(text: str, page_count: int) -> list[str]:
    parts = text.split("\f")
    if parts and parts[-1] == "":
        parts.pop()
    if len(parts) < page_count:
        parts.extend([""] * (page_count - len(parts)))
    return parts[:page_count]


def extract_pdf_pages(path: Path, page_count: int) -> list[PageData]:
    out = run(["pdftotext", "-layout", str(path), "-"]).stdout
    texts = split_pdf_text(out, page_count)
    pages: list[PageData] = []
    for i, text in enumerate(texts, start=1):
        norm = normalize_text(text)
        pages.append(PageData(i, text.strip(), norm, ngrams(norm, 3), ngrams(norm, 4)))
    return pages


def mime_for_path(path: Path | str) -> str:
    suffix = Path(path).suffix.lower()
    return {
        ".pdf": "application/pdf",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".webp": "image/webp",
    }.get(suffix, "application/octet-stream")


def remove_leading_number(stem: str) -> str:
    return re.sub(r"^\s*\d+(?:-\d+)?[._\-\s]*", "", stem)


def build_aliases(rel_path: Path) -> list[tuple[str, int]]:
    stem = rel_path.stem
    aliases: dict[str, int] = {}

    def add(value: str, score: int) -> None:
        norm = normalize_text(value)
        if len(norm) >= 4:
            aliases[norm] = max(score, aliases.get(norm, 0))

    add(stem, 120)
    simple = remove_leading_number(stem)
    add(simple, 82)
    add(re.sub(r"[_\-]?20\d{6}$", "", simple), 86)
    add(re.split(r"[（(]", simple, maxsplit=1)[0], 84)

    # Chapter PDFs: the chapter title is often cited without the common folder name.
    chapter = re.search(r"【(第\d+章)】([^【]+)", stem)
    if chapter:
        add(chapter.group(1) + chapter.group(2), 108)
        add(chapter.group(2), 80)

    # Commonly abbreviated titles in the CSV.
    manual_parts = [
        "関西電力グループ経営計画2026",
        "お客さま情報取扱いマニュアル",
        "客さま情報取扱いマニュアル",
        "適正な電力取引についての指針",
        "電力の小売営業に関する指針",
        "電気特定小売供給約款",
        "電気供給条件低圧",
        "特別高圧高圧分野の標準メニューの見直し",
        "市場価格調整の見直し",
        "関西電力グループゼロカーボンロードマップ",
        "関西電力グループゼロカーボンビジョン2050",
        "関西電力グループ行動憲章",
        "関西電力グループ安全行動憲章",
        "関西電力グループ人権方針",
        "経営理念",
        "2025年度決算説明資料",
        "決算短信",
        "ソリューション本部中期計画",
    ]
    stem_norm = normalize_text(stem)
    for part in manual_parts:
        pnorm = normalize_text(part)
        if pnorm in stem_norm:
            add(part, 92)

    return sorted(aliases.items(), key=lambda x: (-x[1], -len(x[0])))


def collect_documents(extracted_root: Path) -> list[Document]:
    docs: list[Document] = []
    for kind in ("common", "solution"):
        root = extracted_root / kind
        for path in sorted(root.rglob("*")):
            if not path.is_file() or path.suffix.lower() not in SUPPORTED_DOC_EXTS:
                continue
            rel = path.relative_to(root)
            doc_id = f"{kind}-{hashlib.sha1(rel.as_posix().encode('utf-8')).hexdigest()[:12]}"
            page_count = pdf_page_count(path) if path.suffix.lower() == ".pdf" else 1
            docs.append(
                Document(
                    id=doc_id,
                    kind=kind,
                    rel_path=rel,
                    source_path=path,
                    package_path=f"documents/{kind}/{rel.as_posix()}",
                    name=rel.name,
                    mime=mime_for_path(path),
                    page_count=page_count,
                    aliases=build_aliases(rel),
                )
            )
    return docs


def match_documents(source: str, category: str, docs: Sequence[Document]) -> tuple[list[Candidate], bool]:
    source_norm = normalize_text(source)
    source_nfkc = unicodedata.normalize("NFKC", source or "")
    generic_sales = "今日からあなたも営業パーソン" in source_nfkc
    has_specific_chapter = bool(re.search(r"第\s*[1-7]\s*章", source_nfkc))
    has_chapter_range = bool(re.search(r"第\s*1\s*章.*第\s*7\s*章", source_nfkc))
    chapter_docs = [d for d in docs if "今日からあなたも営業パーソン" in d.rel_path.as_posix()]
    if generic_sales and (has_chapter_range or not has_specific_chapter):
        return [Candidate(d, 75 + (3 if d.kind == category else 0), False) for d in chapter_docs], True

    scored: list[Candidate] = []
    for doc in docs:
        best = 0
        for alias, alias_score in doc.aliases:
            if alias and alias in source_norm:
                best = max(best, alias_score)
        if best:
            if doc.kind == category:
                best += 3
            scored.append(Candidate(doc, best, best >= 110))

    # A citation can name both rules separated by ／.
    if "電気特定小売供給約款" in source_nfkc and "電気供給条件" in source_nfkc:
        both = [c for c in scored if "電気特定小売供給約款" in c.doc.name or "電気供給条件" in c.doc.name]
        if both:
            return sorted(both, key=lambda c: -c.match_score), False

    if not scored:
        return [], False
    max_score = max(c.match_score for c in scored)
    if max_score >= 110:
        chosen = [c for c in scored if c.match_score >= 110]
    else:
        chosen = [c for c in scored if c.match_score >= max_score - 1 and c.match_score >= 70]
    chosen.sort(key=lambda c: (-c.match_score, c.doc.kind != category, c.doc.name))
    return chosen, False


def parse_page_hints(source: str) -> tuple[list[int], str | None]:
    value = unicodedata.normalize("NFKC", source or "")
    hints: list[int] = []
    labels: list[str] = []
    range_pattern = re.compile(r"[pP]\.?\s*(\d+)\s*(?:-|~|〜|～)\s*(?:[pP]\.?\s*)?(\d+)")
    consumed: list[tuple[int, int]] = []
    for m in range_pattern.finditer(value):
        a, b = int(m.group(1)), int(m.group(2))
        if a <= b and b - a <= 200:
            hints.extend(range(a, b + 1))
        else:
            hints.extend([a, b])
        labels.append(m.group(0))
        consumed.append(m.span())
    for m in re.finditer(r"[pP]\.?\s*(\d+)", value):
        if any(a <= m.start() < b for a, b in consumed):
            continue
        hints.append(int(m.group(1)))
        labels.append(m.group(0))
    for m in re.finditer(r"\.(?:pdf|png|jpe?g)\s*[,，]\s*(\d+)", value, re.IGNORECASE):
        hints.append(int(m.group(1)))
        labels.append(m.group(1))
    unique = list(dict.fromkeys(hints))
    return unique, (" / ".join(dict.fromkeys(labels)) if labels else None)


def query_parts(qa: str) -> tuple[str, str, list[str], list[str]]:
    answers = [m.group(1).strip() for m in BLANK_RE.finditer(qa or "") if m.group(1).strip()]
    plain = BLANK_RE.sub(lambda m: m.group(1), qa or "").strip()
    query_norm = normalize_text(plain)
    segments = [normalize_text(x) for x in re.split(r"[。．.!！?？、,，;；:\n]", plain)]
    segments = sorted({x for x in segments if len(x) >= 5}, key=len, reverse=True)
    return plain, query_norm, answers, segments


def page_score(page: PageData, query_norm: str, answers: Sequence[str], segments: Sequence[str]) -> float:
    if not page.norm:
        return 0.0
    n = 4 if len(query_norm) >= 20 else 3
    qgrams = ngrams(query_norm, n)
    pgrams = page.grams4 if n == 4 else page.grams3
    coverage = len(qgrams & pgrams) / max(1, len(qgrams))

    answer_norms = [normalize_text(a) for a in answers if normalize_text(a)]
    total_weight = sum(max(1, min(20, len(a))) for a in answer_norms)
    hit_weight = sum(max(1, min(20, len(a))) for a in answer_norms if a in page.norm)
    answer_score = hit_weight / total_weight if total_weight else 0.0

    fragment_score = 0.0
    for seg in segments[:8]:
        if seg and seg in page.norm:
            fragment_score = max(fragment_score, min(1.0, len(seg) / 28.0))

    return 0.62 * coverage + 0.28 * answer_score + 0.10 * fragment_score


def physical_hint_pages(doc: Document, hints: Sequence[int]) -> list[int]:
    if not hints:
        return []
    # The two-page scanned management philosophy file uses source labels p.0/p.1 on
    # physical page 1 and p.2 on physical page 2.
    if doc.kind == "common" and doc.name.startswith("02.経営理念"):
        mapped = [1 if h <= 1 else min(h, doc.page_count) for h in hints]
        return list(dict.fromkeys(mapped))
    return [h for h in hints if 1 <= h <= doc.page_count]


def select_page(doc: Document, query_norm: str, answers: Sequence[str], segments: Sequence[str], hints: Sequence[int]) -> tuple[int | None, float]:
    if doc.is_image:
        return 1, 1.0
    hint_pages = physical_hint_pages(doc, hints)
    scored: list[tuple[float, int]] = []
    for page in doc.pages:
        score = page_score(page, query_norm, answers, segments)
        if page.number in hint_pages:
            score += 0.24
        elif any(abs(page.number - h) == 1 for h in hint_pages):
            score += 0.05
        scored.append((score, page.number))
    if not scored:
        return (hint_pages[0] if hint_pages else None), 0.0
    scored.sort(reverse=True)
    best_score, best_page = scored[0]

    # Explicit physical page references remain authoritative unless text strongly
    # contradicts them. This also handles pages whose text cannot be extracted.
    if hint_pages:
        hint_best = max((s, p) for s, p in scored if p in hint_pages)
        raw_hint_score = page_score(doc.pages[hint_best[1] - 1], query_norm, answers, segments)
        raw_best_score = page_score(doc.pages[best_page - 1], query_norm, answers, segments)
        if not doc.pages[hint_best[1] - 1].norm or raw_hint_score >= raw_best_score * 0.58:
            return hint_best[1], hint_best[0]
    if best_score <= 0.015 and not hint_pages:
        return None, best_score
    return best_page, best_score


def window_score(text: str, query_norm: str, answers: Sequence[str]) -> float:
    norm = normalize_text(text)
    if not norm:
        return 0.0
    n = 3 if len(query_norm) < 25 else 4
    qg = ngrams(query_norm, n)
    cov = len(qg & ngrams(norm, n)) / max(1, len(qg))
    answer_norms = [normalize_text(a) for a in answers if normalize_text(a)]
    ans = sum(1 for a in answer_norms if a in norm) / max(1, len(answer_norms))
    return cov + ans * 0.7


def make_excerpt(page_text: str, query_norm: str, answers: Sequence[str]) -> str:
    # pdftotext -layout は段組みを大量の空白で表現する。画面表示用の抜粋では
    # 連続空白を畳み、行頭・行末も除いて読みやすくする。
    lines = [re.sub(r"[ \t]{2,}", " ", line).strip() for line in page_text.splitlines()]
    nonempty = [(i, line) for i, line in enumerate(lines) if line]
    if not nonempty:
        return ""
    best_score = -1.0
    best_start = nonempty[0][0]
    best_end = best_start
    for idx in range(len(nonempty)):
        for width in (1, 2, 3, 4):
            chunk = nonempty[idx : idx + width]
            if not chunk:
                continue
            start, end = chunk[0][0], chunk[-1][0]
            text = "\n".join(lines[start : end + 1])
            score = window_score(text, query_norm, answers)
            if score > best_score:
                best_score, best_start, best_end = score, start, end
    start = max(0, best_start - 2)
    end = min(len(lines), best_end + 3)
    excerpt_lines = lines[start:end]
    while excerpt_lines and not excerpt_lines[0].strip():
        excerpt_lines.pop(0)
    while excerpt_lines and not excerpt_lines[-1].strip():
        excerpt_lines.pop()
    excerpt = "\n".join(excerpt_lines).strip()
    if len(excerpt) > 850:
        excerpt = excerpt[:847].rstrip() + "..."
    return excerpt


def parse_bbox_words(pdf: Path, page: int, work_dir: Path) -> tuple[float, float, list[dict]]:
    out = work_dir / f"bbox-{hashlib.sha1(str(pdf).encode()).hexdigest()[:8]}-{page}.html"
    run(["pdftotext", "-f", str(page), "-l", str(page), "-bbox-layout", str(pdf), str(out)])
    try:
        root = ET.parse(out).getroot()
    finally:
        out.unlink(missing_ok=True)
    page_el = next((el for el in root.iter() if el.tag.endswith("page")), None)
    if page_el is None:
        return 1.0, 1.0, []
    width = float(page_el.attrib.get("width", "1")) or 1.0
    height = float(page_el.attrib.get("height", "1")) or 1.0
    words: list[dict] = []
    for el in page_el.iter():
        if not el.tag.endswith("word"):
            continue
        text = "".join(el.itertext()).strip()
        if not text:
            continue
        words.append(
            {
                "text": text,
                "x0": float(el.attrib.get("xMin", "0")),
                "y0": float(el.attrib.get("yMin", "0")),
                "x1": float(el.attrib.get("xMax", "0")),
                "y1": float(el.attrib.get("yMax", "0")),
            }
        )
    return width, height, words


def find_occurrences(haystack: str, needle: str) -> list[int]:
    out: list[int] = []
    start = 0
    while needle and True:
        pos = haystack.find(needle, start)
        if pos < 0:
            break
        out.append(pos)
        start = pos + 1
    return out


def merge_word_boxes(words: list[dict], indexes: Sequence[int], width: float, height: float) -> list[dict[str, float]]:
    selected = [words[i] for i in sorted(set(indexes)) if 0 <= i < len(words)]
    if not selected:
        return []
    merged: list[list[dict]] = []
    for word in selected:
        if not merged:
            merged.append([word])
            continue
        prev = merged[-1][-1]
        same_line = abs(word["y0"] - prev["y0"]) <= max(2.5, (prev["y1"] - prev["y0"]) * 0.35)
        close = word["x0"] - prev["x1"] <= 18
        if same_line and close:
            merged[-1].append(word)
        else:
            merged.append([word])
    boxes: list[dict[str, float]] = []
    for group in merged:
        x0 = max(0.0, min(w["x0"] for w in group) - 2.0)
        y0 = max(0.0, min(w["y0"] for w in group) - 1.5)
        x1 = min(width, max(w["x1"] for w in group) + 2.0)
        y1 = min(height, max(w["y1"] for w in group) + 1.5)
        boxes.append(
            {
                "x": round(x0 / width, 6),
                "y": round(y0 / height, 6),
                "w": round((x1 - x0) / width, 6),
                "h": round((y1 - y0) / height, 6),
            }
        )
    return boxes


def make_marker_boxes(pdf: Path, page: int, answers: Sequence[str], segments: Sequence[str], work_dir: Path) -> tuple[list[dict[str, float]], str | None]:
    width, height, words = parse_bbox_words(pdf, page, work_dir)
    if not words:
        return [], None
    char_to_word: list[int] = []
    normalized_words: list[str] = []
    for i, word in enumerate(words):
        norm = normalize_text(word["text"])
        normalized_words.append(norm)
        char_to_word.extend([i] * len(norm))
    joined = "".join(normalized_words)
    if not joined:
        return [], None

    anchor = -1
    for seg in segments:
        if len(seg) < 5:
            continue
        anchor = joined.find(seg)
        if anchor >= 0:
            break

    selected_indexes: list[int] = []
    for answer in answers:
        needle = normalize_text(answer)
        if not needle:
            continue
        positions = find_occurrences(joined, needle)
        if not positions:
            continue
        pos = min(positions, key=lambda p: abs(p - anchor)) if anchor >= 0 else positions[0]
        end = min(len(char_to_word), pos + len(needle))
        selected_indexes.extend(char_to_word[pos:end])

    marker_mode = "answers" if selected_indexes else None
    if not selected_indexes:
        # Fallback: mark the longest exact context segment so the source location is
        # still visible even when answer glyphs were converted oddly in the PDF.
        for seg in segments:
            if len(seg) < 8:
                continue
            pos = joined.find(seg)
            if pos >= 0:
                end = min(len(char_to_word), pos + len(seg))
                selected_indexes.extend(char_to_word[pos:end])
                marker_mode = "context"
                break
    boxes = merge_word_boxes(words, selected_indexes, width, height)
    return boxes[:40], marker_mode


def render_pdf_preview(pdf: Path, page: int, output: Path) -> None:
    output.parent.mkdir(parents=True, exist_ok=True)
    prefix = output.with_suffix("")
    run(
        [
            "pdftoppm",
            "-f",
            str(page),
            "-l",
            str(page),
            "-singlefile",
            "-r",
            "110",
            "-jpeg",
            "-jpegopt",
            "quality=82,optimize=y",
            str(pdf),
            str(prefix),
        ]
    )
    generated = prefix.with_suffix(".jpg")
    if generated != output:
        generated.replace(output)


def page_label(source_label: str | None, page: int | None, hints: Sequence[int], auto: bool) -> str:
    if page is None:
        return source_label or "該当資料"
    if source_label:
        physical = set(hints)
        if len(physical) == 1 and page in physical:
            return source_label
        return f"{source_label} / PDF {page}ページ"
    return f"PDF {page}ページ" + ("（自動照合）" if auto else "")


def parse_qa_cell(qa: str) -> tuple[str, str]:
    text = (qa or "").strip()
    matches = list(BLANK_RE.finditer(text))
    if not matches:
        return text, text
    blanks: list[str] = []
    if len(matches) == 1:
        question = BLANK_RE.sub(lambda m: blanks.append(m.group(1).strip()) or "【】", text, count=1)
        return question, blanks[0]

    def repl(match: re.Match[str]) -> str:
        blanks.append(match.group(1).strip())
        return f"【{CIRCLED[len(blanks) - 1] if len(blanks) <= len(CIRCLED) else len(blanks)}】"

    question = BLANK_RE.sub(repl, text)
    answer = "　".join(
        f"{CIRCLED[i] if i < len(CIRCLED) else i + 1} {blank}" for i, blank in enumerate(blanks)
    )
    return question, answer


def app_content_hash(qa: str) -> str:
    question, answer = parse_qa_cell(qa)
    value = question + "\0" + answer
    h = 5381
    for ch in value:
        # JavaScript charCodeAt uses UTF-16 code units. All expected Japanese source
        # text is BMP, but handle non-BMP safely for reproducibility.
        encoded = ch.encode("utf-16-le")
        units = [int.from_bytes(encoded[i : i + 2], "little") for i in range(0, len(encoded), 2)]
        for unit in units:
            h = ((h << 5) + h + unit) & 0xFFFFFFFF
    digits = "0123456789abcdefghijklmnopqrstuvwxyz"
    if h == 0:
        return "0"
    out = ""
    while h:
        h, rem = divmod(h, 36)
        out = digits[rem] + out
    return out


def load_questions(path: Path) -> list[dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as fh:
        rows = list(csv.DictReader(fh))
    required = {"id", "category", "Q&A", "source"}
    missing = required - set(rows[0].keys() if rows else [])
    if missing:
        raise SystemExit("CSV is missing column(s): " + ", ".join(sorted(missing)))
    return rows


def build_package(args: argparse.Namespace) -> None:
    require_commands(["pdfinfo", "pdftotext", "pdftoppm"])
    questions_path = args.questions.resolve()
    output = args.output.resolve()
    report_path = args.report.resolve() if args.report else output.with_suffix(".coverage.csv")
    output.parent.mkdir(parents=True, exist_ok=True)
    report_path.parent.mkdir(parents=True, exist_ok=True)

    with tempfile.TemporaryDirectory(prefix="s2-source-build-") as tmp_name:
        tmp = Path(tmp_name)
        extracted = tmp / "extracted"
        package_root = tmp / "package"
        preview_root = package_root / "previews"
        extracted.mkdir(parents=True)
        package_root.mkdir(parents=True)

        log("[1/7] Extracting source ZIPs...")
        extract_source_zip(args.common_zip.resolve(), extracted, "common")
        extract_source_zip(args.solution_zip.resolve(), extracted, "solution")

        log("[2/7] Reading source documents...")
        docs = collect_documents(extracted)
        by_id = {d.id: d for d in docs}
        for index, doc in enumerate(docs, start=1):
            if doc.is_pdf:
                log(f"  text {index}/{len(docs)}: {doc.kind}/{doc.rel_path}")
                doc.pages = extract_pdf_pages(doc.source_path, doc.page_count)
            else:
                doc.pages = [PageData(1, "", "")]

        rows = load_questions(questions_path)
        manifest_questions: dict[str, dict] = {}
        content_index: dict[str, list[str]] = defaultdict(list)
        report_rows: list[dict[str, object]] = []
        selected_preview_keys: dict[tuple[str, int], Path] = {}
        references_for_bbox: list[tuple[dict, Document, int, list[str], list[str]]] = []

        log("[3/7] Matching questions to documents/pages...")
        for row_index, row in enumerate(rows, start=1):
            original_id = (row.get("id") or "").strip()
            # CSV取込時、idが空の行にはアプリ側でランダムIDが付く。
            # 出典照合はcontentIndexでも行うため、パッケージ内では安定した仮IDを与える。
            qid = original_id or f"__source_row_{row_index:06d}"
            qa = row.get("Q&A") or ""
            source = row.get("source") or ""
            category = (row.get("category") or "common").strip().lower()
            plain, query_norm, answers, segments = query_parts(qa)
            hints, hint_label = parse_page_hints(source)
            candidates, choose_one = match_documents(source, category, docs)
            matches: list[PageMatch] = []

            for cand in candidates:
                page, score = select_page(cand.doc, query_norm, answers, segments, hints)
                excerpt = ""
                boxes: list[dict[str, float]] = []
                marker_mode: str | None = None
                preview_path: str | None = None
                if cand.doc.is_image:
                    preview_path = cand.doc.package_path
                elif page is not None:
                    page_data = cand.doc.pages[page - 1]
                    excerpt = make_excerpt(page_data.text, query_norm, answers)
                    preview_path = f"previews/{cand.doc.id}/page-{page}.jpg"
                    selected_preview_keys[(cand.doc.id, page)] = preview_root / cand.doc.id / f"page-{page}.jpg"
                matches.append(
                    PageMatch(
                        doc=cand.doc,
                        page=page,
                        score=score,
                        excerpt=excerpt,
                        boxes=boxes,
                        preview_path=preview_path,
                        page_label=page_label(hint_label, page, hints, auto=not bool(hints)),
                        explicit=cand.explicit,
                        marker_mode=marker_mode,
                    )
                )

            if choose_one and matches:
                matches.sort(key=lambda m: (m.page is not None, m.score), reverse=True)
                matches = matches[:1]

            refs: list[dict] = []
            for match in matches:
                ref = {
                    "documentId": match.doc.id,
                    "documentName": match.doc.name,
                    "page": match.page,
                    "pageLabel": match.page_label,
                    "excerpt": match.excerpt,
                    "highlights": answers,
                    "boxes": [],
                    "previewPath": match.preview_path,
                    "score": round(match.score, 4),
                    "isCandidate": False,
                }
                refs.append(ref)
                if match.doc.is_pdf and match.page is not None:
                    references_for_bbox.append((ref, match.doc, match.page, answers, segments))

            content_hash = app_content_hash(qa)
            entry = {
                "contentHash": content_hash,
                "sourceText": source,
                "highlights": answers,
                "references": refs,
            }
            manifest_questions[qid] = entry
            content_index[content_hash].append(qid)

            report_rows.append(
                {
                    "csv_line": row_index + 1,
                    "id": original_id,
                    "manifest_id": qid,
                    "category": category,
                    "Q&A": qa,
                    "source": source,
                    "mapped": "yes" if refs else "no",
                    "document": " | ".join(r["documentName"] for r in refs),
                    "pdf_page": " | ".join(str(r["page"] or "") for r in refs),
                    "page_label": " | ".join(r["pageLabel"] for r in refs),
                    "score": " | ".join(str(r["score"]) for r in refs),
                    "markers": 0,
                }
            )
            if row_index % 50 == 0:
                log(f"  matched {row_index}/{len(rows)} questions")

        log("[4/7] Locating marker rectangles...")
        marker_counts: dict[str, int] = defaultdict(int)
        for index, (ref, doc, page, answers, segments) in enumerate(references_for_bbox, start=1):
            try:
                boxes, mode = make_marker_boxes(doc.source_path, page, answers, segments, tmp)
            except Exception as exc:
                log(f"  warning: marker failed for {doc.name} p.{page}: {exc}")
                boxes, mode = [], None
            ref["boxes"] = boxes
            if mode:
                ref["markerMode"] = mode
            marker_counts[doc.id] += len(boxes)
            if index % 40 == 0:
                log(f"  markers {index}/{len(references_for_bbox)}")

        # Update report marker counts by looking up final refs.
        for rr in report_rows:
            refs = manifest_questions[str(rr["manifest_id"])]["references"]
            rr["markers"] = sum(len(r.get("boxes") or []) for r in refs)

        log(f"[5/7] Rendering {len(selected_preview_keys)} unique page previews...")
        for index, ((doc_id, page), out_path) in enumerate(selected_preview_keys.items(), start=1):
            doc = by_id[doc_id]
            render_pdf_preview(doc.source_path, page, out_path)
            if index % 20 == 0:
                log(f"  previews {index}/{len(selected_preview_keys)}")

        log("[6/7] Staging original documents...")
        manifest_documents: dict[str, dict] = {}
        for doc in docs:
            target = package_root / doc.package_path
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(doc.source_path, target)
            manifest_documents[doc.id] = {
                "id": doc.id,
                "group": doc.kind,
                "name": doc.name,
                "relativeName": doc.rel_path.as_posix(),
                "path": doc.package_path,
                "mime": doc.mime,
                "pageCount": doc.page_count,
            }

        mapped = sum(1 for q in manifest_questions.values() if q["references"])
        marked = sum(1 for q in manifest_questions.values() if any(r.get("boxes") for r in q["references"]))
        package_id = "s2-" + hashlib.sha256(
            (questions_path.read_bytes() + args.common_zip.read_bytes()[:4096] + args.solution_zip.read_bytes()[:4096])
        ).hexdigest()[:16]
        manifest = {
            "schemaVersion": 1,
            "packageId": package_id,
            "name": "S2 出典ライブラリ（共通・ソリューション）",
            "createdAt": datetime.now(timezone.utc).isoformat(),
            "questionFile": questions_path.name,
            "documents": manifest_documents,
            "questions": manifest_questions,
            "contentIndex": dict(content_index),
            "stats": {
                "totalQuestions": len(manifest_questions),
                "mappedQuestions": mapped,
                "markedQuestions": marked,
                "documents": len(manifest_documents),
                "previewPages": len(selected_preview_keys),
            },
        }
        (package_root / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
        (package_root / "README-LOCAL.txt").write_text(
            "このZIPには出典PDF・画像と問題対応索引が含まれます。GitHubへアップロードしないでください。\n"
            "学習アプリの 設定 > 出典資料（端末内のみ） から読み込んでください。\n",
            encoding="utf-8",
        )

        with report_path.open("w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=list(report_rows[0].keys()))
            writer.writeheader()
            writer.writerows(report_rows)

        log("[7/7] Writing uncompressed import ZIP...")
        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_STORED, allowZip64=False) as zf:
            for path in sorted(package_root.rglob("*")):
                if path.is_file():
                    zf.write(path, path.relative_to(package_root).as_posix())

    log(f"Done: {output} ({output.stat().st_size / 1024 / 1024:.1f} MB)")
    log(f"Coverage report: {report_path}")
    log(f"Mapped {mapped}/{len(manifest_questions)} questions; markers on {marked} questions.")


def parse_args(argv: Sequence[str] | None = None) -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--questions", type=Path, required=True, help="questions CSV")
    parser.add_argument("--common-zip", type=Path, required=True, help="共通 ZIP")
    parser.add_argument("--solution-zip", type=Path, required=True, help="ソリューション ZIP")
    parser.add_argument("--output", type=Path, required=True, help="output .local.zip")
    parser.add_argument("--report", type=Path, help="optional coverage CSV")
    return parser.parse_args(argv)


def main(argv: Sequence[str] | None = None) -> int:
    args = parse_args(argv)
    build_package(args)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
